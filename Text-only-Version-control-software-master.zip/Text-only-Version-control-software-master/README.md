# Text-only-Version-control-software
Online text editor with Version control software and collaboration
# How to Run
0. Install Postgres Database
1. Make a Virtual Evironment
2. run the virual environment
3. pip install django
4. pip install psycopg2
4. py manage.py runserver
