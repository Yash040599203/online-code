from django.apps import AppConfig


class VcConfig(AppConfig):
    name = 'vc'
